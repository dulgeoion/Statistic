var array = [];

$("#tableButton").click(function(array){
	$("#table").html("");

	$("#frequency").html("");
	$("#table").show();
	var content = "<h3>Введіть розмірність матриці: </h3></br>";
		content += '<table><tr><td>Рядки: </td><td><input type="text" name="rows" ></td></tr>';
		content += '<tr><td>Стовпці: </td> <td><input type="text" name="columns"></td></tr></table>';
		content += '<input type="button" name="enterMatrix" value="Продовжити">';

	$("#table").append(content);
	$("#table").append("<div id='tmpt'></div>");

	$("input[name='enterMatrix']").click(function(array){
		
		var row = $("input[name='rows']").val();
		
		var column = $("input[name='columns']").val();
		$("#tmpt").html("");
		createTable(row, column, "tmpt");
		$('input[name="buttonApply"').click(function(array){
	alert(22);
	

	alert($("input[name='rows']").val());
	readTable(array, $("input[name='rows']").val(), $("input[name='columns']").val());

});
	});
	
	
});
$("#frequencyButton").click(function(){
	$("#table").html("");
	$("#frequency").html("");
	

	var content = "<h3>Введіть довжину статистичного розподілу: </h3></br>";
		content += '<table><tr><td>Довжина: </td><td><input type="text" name="length" ></td></tr>';
		content += '</table>';
		content += '<input type="button" name="enterFrequency" value="Продовжити">';
		$("#frequency").append(content);

	$("#frequency").append("<div id='tmpf'></div>");

	$("input[name='enterFrequency']").click(function(){
		
		var length =$("input[name='length']").val();
		$("#tmp").html("");
		createTable(2, length, "tmpf");
		$("input[name='0,0']").parent().html("x<sub>i</sub>");
		$("input[name='1,0']").parent().html("n<sub>i</sub>");


	});
});

console.log(array[0][0]);