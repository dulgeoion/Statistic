var s = "";
var avg = 0;
for (var i = 0; i<20; i++){
		avg+= n[i]*x[i];
		
		s += n[i]*x[i]+" + ";

}
s = s+ " = "+avg;

avg /= 40;
s = s+ " = "+avg;
console.log(s);
var Ms = "";
var ms = "";

var M = [];
var m = [];

for ( var i=1; i<5; i++){
	M[i] = 0;
	m[i] = 0;
	for (var j = 0; j<20; j++){
		M[i] += n[j]*parseFloat(Math.pow(x[j], i));
		Ms += n[j]*parseFloat(Math.pow(x[j], i))+" + ";

		m[i] += n[j]*parseFloat(Math.pow(x[j]-avg, i));
		ms += n[j]*parseFloat(Math.pow(x[j]-avg, i)) + " + "; 		
	}

	console.log("M"+i+" = "+Ms+"/ 40 ="+M[i].toFixed(4)+"/"+40+" = "+(M[i]/40).toFixed(4));
	console.log("m"+i+" = "+ms+"/ 40 ="+m[i]+"/"+40+" = "+(m[i]/40));
	Ms = "";
	ms = "";
}
