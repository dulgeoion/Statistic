function createTable(rows, columns, name){
if (name=="tmpf"){
	columns++;
}
var content = "<table>";
for (i = 0; i< rows; i++){
	content += "<tr>";
	for (j = 0; j< columns; j++){
		content += '<td><input type="text" name="'+i+','+j+'"></td>';
	}
	content += "</tr>";
}

content += "</table>";
content += "<input type='button' name='buttonApply' value='Продовжити'>"

$('#'+name).append(content);


}

function readTable(arr, rows, columns){
	for (var i = 0; i<rows; i++){
		arr[i] = [];
		for (var j = 0; j<columns; j++){
			arr[i][j] = $("table").find('input[name="'+i+','+j+'"]').val();
			alert(arr[i][j]);

		}
	}
}

function setStatisticFrequency(name){

}